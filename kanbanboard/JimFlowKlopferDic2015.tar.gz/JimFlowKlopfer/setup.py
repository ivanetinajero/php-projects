from distutils.core import setup
setup(name='jimflowklopfer',
      version='0.1',
      package_dir={'jimflowklopfer': 'src'},
      packages=['jimflowklopfer'],
      )
